#ifndef __TEST_TASK_H__
#define __TEST_TASK_H__

void test_task(void const *argu);

#endif
