#ifndef _BSP_SUPERCAP_H
#define _BSP_SUPERCAP_H

#include "stm32f4xx_hal.h"
void super_cap_control(int8_t supercap_mode,int8_t supercap_discharged,int8_t supercap_charged);

#endif
