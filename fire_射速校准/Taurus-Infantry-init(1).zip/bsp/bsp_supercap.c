#include "bsp_supercap.h"
#include "comm_task.h"
void super_cap_control(int8_t supercap_mode,int8_t supercap_discharged,int8_t supercap_charged)
{

}
